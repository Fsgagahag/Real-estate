import { useState } from "react";


const Navbar = () => {
 const [show, setshow] = useState(false)
  return (
    <nav className=" h-16 flex   ">
     
      <div className='flex justify-between gap-9 '>
        
        <div>
          <h1 className='text-indigo-600 text-3xl  mx-26'> Real estate </h1>

        </div>
        <div className=' hidden md:block mr-52'>
         <a href="#home" className='hover:text-indigo-600 mx-6 font-bold text-2xl '>Home</a>
         <a href="#About" className='hover:text-indigo-600 mx-6 font-bold text-2xl '>About</a>
         <a href="#Contact" className=' hover:text-indigo-600 mx-6 font-bold text-2xl '>Contact</a>
         <a href="#Listing" className='hover:text-indigo-600 mx-6 font-bold text-2xl'>listings</a>
        </div>

        <div className='ml-60'>
          
        <a href="#login" className='bg-indigo-600 text-2xl rounded-xl  '> Login</a>
        <a href="#Signup" className='hover:text-indigo-600  text-2xl '> sign-up</a>
        </div>
        <button >  
          <img onClick= {()=>(show(true))}src="https://cdn.icon-icons.com/icons2/37/PNG/512/list_3600.png" className='lg:hidden h-7 justify-end block md:hidden' alt="" />
        </button>
      </div>
      
              
            
           
         
      
      
    </nav>
   
  );
};

export default Navbar;
