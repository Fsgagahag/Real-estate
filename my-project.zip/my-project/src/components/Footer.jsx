import React from 'react';

function Footer() {
  return (
    <footer className="bg-gray-800 text-gray-200 py-4">
      <div className="container mx-auto text-center">
        <p className="text-sm">
          Made with  by <span className="font-bold">Rahul Gupta</span>
        </p>
      </div>
    </footer>
  );
}

export default Footer;
