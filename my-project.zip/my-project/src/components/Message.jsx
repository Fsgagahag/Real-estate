import React, { useState } from 'react'
 
  const Message = () => {
    const [name, setname] = useState('');
   const [email, setemail] = useState('')
    const submit = (e) => {
      e.prevent.default()
      console.log("hellow form submit")
      setemail('')
      setname('')
      
    }

  
  
  

  return (
    
         
    <div className='h-screen w-screen items-center justify-between'>
       
     <div className='rounded-xl bg-gray-400 h-screen '>
     <h1 className='text-indigo-600 text-3xl px-14'>for any query </h1>
      <form onSubmit={(e)=>{submit(e)}}
       className='flex flex-col items-center justify-center m-40'
      > <h2 className='font-bold text-xl'>Name</h2>
       <input value={name} placeholder='entre your name 'onChange={(e)=>{setname(e.target.name)}} /> 
       <h3 className='font-bold text-xl '>Email</h3>
       <input value={email} placeholder='entre your eamail ' onChange={(e)=>{setname(e.target.email)}} /> 
       <h4>Message</h4>
       <textarea name="entre your message" id="" cols={30} rows={10}></textarea>
       <button className='bg-indigo-600 rounded-sm mt-7'>sumbit</button>
       
      
      </form>
         
     </div>
    </div>
  )

  }
export default Message
