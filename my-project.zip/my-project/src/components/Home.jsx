import React from 'react'
import Navbar from "./Navbar"; 

const Home = () => {
  return (
    <div className='bg-cover bg-centre h-screen w-full 'style={{backgroundImage:"url('https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?cs=srgb&dl=architecture-family-house-front-yard-106399.jpg&fm=jpg')"}} id='Home'> 
      <Navbar/>
     
      <h1 className=' font-bold text-3xl  '> build ypur home </h1>
      <p className=' font-bold text-3xl'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. </p>
     


    </div>
     
  )
}

export default Home